import React from 'react'

export default function Footer() {
  return (
    <div className='footer'>
        <p>@copyright imaginary engineering</p>
    </div>
  )
}
